-- =====================================================================
--  PASSO 06 - Conferir o import, recompilar e coletar estatisticas
--  Rodar com:  @06_pos_import.sql
-- =====================================================================
@@00_config.sql
SPOOL passo06_resultado.txt

PROMPT
PROMPT ================================================================
PROMPT  PASSO 06 - Conferir o resultado do import
PROMPT ================================================================
PROMPT

VARIABLE seguir VARCHAR2(1)

-- ---------------------------------------------------------------
-- Parte 1: o import terminou? Que erros deu?
-- ---------------------------------------------------------------
DECLARE
  v_n      NUMBER;
  v_graves NUMBER := 0;

  PROCEDURE p(t VARCHAR2) IS BEGIN DBMS_OUTPUT.PUT_LINE(t); END;

  FUNCTION explica(cod VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    RETURN CASE cod
      WHEN 'ORA-31684' THEN 'ok    | objeto ja existia (ex.: usuario). Pode ignorar.'
      WHEN 'ORA-39151' THEN 'ok    | tabela ja existia e foi pulada.'
      WHEN 'ORA-01917' THEN 'ok    | grant para usuario/role que nao existe no RDS.'
      WHEN 'ORA-01918' THEN 'ok    | grant para usuario que nao existe no RDS.'
      WHEN 'ORA-01919' THEN 'ok    | role nao existe no RDS (veja se a aplicacao usa).'
      WHEN 'ORA-01927' THEN 'ok    | revoke de algo que nao foi concedido.'
      WHEN 'ORA-39082' THEN 'ok    | objeto compilou com erro; o recompile abaixo resolve.'
      WHEN 'ORA-39083' THEN 'VER   | objeto NAO foi criado; a causa e o ORA- seguinte.'
      WHEN 'ORA-00959' THEN 'GRAVE | tablespace nao existe.'
      WHEN 'ORA-01950' THEN 'GRAVE | usuario sem quota na tablespace.'
      WHEN 'ORA-01031' THEN 'VER   | falta de privilegio (comum no RDS em objetos de sistema).'
      WHEN 'ORA-01536' THEN 'GRAVE | quota da tablespace estourou.'
      WHEN 'ORA-01653' THEN 'GRAVE | sem espaco para a tabela (storage do RDS cheio?).'
      WHEN 'ORA-01654' THEN 'GRAVE | sem espaco para o indice (storage do RDS cheio?).'
      ELSE                  'VER   | verificar.'
    END;
  END;
BEGIN
  :seguir := 'N';

  SELECT COUNT(*) INTO v_n FROM dba_datapump_jobs
   WHERE owner_name = USER AND job_name = '&JOB_IMP';
  IF v_n > 0 THEN
    p('[ESPERE] O import ainda esta rodando. Acompanhe com @05_acompanhar.sql');
    p('         e rode este passo so quando ele terminar.');
    RETURN;
  END IF;

  BEGIN
    SELECT COUNT(*) INTO v_n
      FROM TABLE(rdsadmin.rds_file_util.read_text_file('&DP_DIR', '&LOG_IMP'));
  EXCEPTION WHEN OTHERS THEN
    p('[ERRO] Nao achei o log do import (&LOG_IMP). Voce rodou o passo 04?');
    RETURN;
  END;

  p('ERROS/AVISOS DO IMPORT (codigo, quantidade, o que significa):');
  p('');
  v_n := 0;
  FOR r IN (SELECT REGEXP_SUBSTR(text, 'ORA-[0-9]{5}') AS cod, COUNT(*) AS qtd
              FROM TABLE(rdsadmin.rds_file_util.read_text_file('&DP_DIR', '&LOG_IMP'))
             WHERE REGEXP_LIKE(text, 'ORA-[0-9]{5}')
             GROUP BY REGEXP_SUBSTR(text, 'ORA-[0-9]{5}')
             ORDER BY 2 DESC) LOOP
    v_n := v_n + 1;
    p('   ' || RPAD(r.cod, 11) || LPAD(r.qtd, 6) || '   ' || explica(r.cod));
    IF explica(r.cod) LIKE 'GRAVE%' THEN v_graves := v_graves + 1; END IF;
  END LOOP;
  IF v_n = 0 THEN p('   Nenhum. Import limpo.'); END IF;

  -- mostra exemplos dos que precisam de atencao
  v_n := 0;
  FOR r IN (SELECT text
              FROM TABLE(rdsadmin.rds_file_util.read_text_file('&DP_DIR', '&LOG_IMP'))
             WHERE REGEXP_LIKE(text, 'ORA-(39083|00959|01950|01031|01536|01653|01654)')) LOOP
    IF v_n = 0 THEN p(''); p('EXEMPLOS DOS ERROS PARA VERIFICAR (no maximo 15):'); END IF;
    v_n := v_n + 1;
    p('   ' || SUBSTR(r.text, 1, 190));
    EXIT WHEN v_n >= 15;
  END LOOP;

  p('');
  IF v_graves > 0 THEN
    p('[ATENCAO] Tem erro GRAVE acima. Mande o passo06_resultado.txt para o Gustavo');
    p('          antes de liberar o banco para a aplicacao.');
  END IF;

  :seguir := 'S';
END;
/

PROMPT
PROMPT Recompilando objetos e coletando estatisticas...
PROMPT Isso pode demorar varios minutos. NAO feche o SQL*Plus.
PROMPT

-- ---------------------------------------------------------------
-- Parte 2: recompilar, estatisticas e relatorio final
-- ---------------------------------------------------------------
DECLARE
  v_total NUMBER;
  v_inv   NUMBER;
  v_lista VARCHAR2(32767);

  PROCEDURE p(t VARCHAR2) IS BEGIN DBMS_OUTPUT.PUT_LINE(t); END;
BEGIN
  IF NVL(:seguir, 'N') <> 'S' THEN
    p('(parte 2 nao executada - veja a mensagem acima)');
    RETURN;
  END IF;

  FOR s IN (SELECT m.username FROM mig_schemas m
             WHERE m.importar = 'S'
               AND NOT EXISTS (SELECT 1 FROM dba_users u WHERE u.username = m.username)) LOOP
    p('[ERRO] O schema ' || s.username || ' NAO foi criado no RDS!');
  END LOOP;

  FOR s IN (SELECT m.username FROM mig_schemas m
             WHERE m.importar = 'S'
               AND EXISTS (SELECT 1 FROM dba_users u WHERE u.username = m.username)
             ORDER BY m.username) LOOP
    BEGIN
      DBMS_UTILITY.COMPILE_SCHEMA(schema => s.username, compile_all => FALSE);
      p('[OK] Recompilado:              ' || s.username);
    EXCEPTION WHEN OTHERS THEN
      p('[AVISO] Recompilar ' || s.username || ': ' || SQLERRM);
    END;

    BEGIN
      DBMS_STATS.GATHER_SCHEMA_STATS(ownname => s.username, degree => 1);
      p('[OK] Estatisticas coletadas:   ' || s.username);
    EXCEPTION WHEN OTHERS THEN
      p('[AVISO] Estatisticas ' || s.username || ': ' || SQLERRM);
    END;

    v_lista := v_lista || CASE WHEN v_lista IS NOT NULL THEN ',' END || '''' || s.username || '''';
  END LOOP;

  p('');
  p('RESUMO POR SCHEMA:');
  p('   ' || RPAD('SCHEMA', 30) || LPAD('OBJETOS', 10) || LPAD('INVALIDOS', 12));
  FOR s IN (SELECT m.username FROM mig_schemas m WHERE m.importar = 'S' ORDER BY m.username) LOOP
    SELECT COUNT(*), NVL(SUM(CASE WHEN status = 'INVALID' THEN 1 ELSE 0 END), 0)
      INTO v_total, v_inv
      FROM dba_objects WHERE owner = s.username;
    p('   ' || RPAD(s.username, 30) || LPAD(v_total, 10) || LPAD(v_inv, 12));
  END LOOP;

  v_inv := 0;
  FOR o IN (SELECT o.owner, o.object_type, o.object_name
              FROM dba_objects o JOIN mig_schemas m ON m.username = o.owner
             WHERE m.importar = 'S' AND o.status = 'INVALID'
             ORDER BY 1, 2, 3) LOOP
    IF v_inv = 0 THEN p(''); p('OBJETOS INVALIDOS (no maximo 30):'); END IF;
    v_inv := v_inv + 1;
    p('   ' || o.owner || '.' || o.object_name || '  (' || o.object_type || ')');
    EXIT WHEN v_inv >= 30;
  END LOOP;

  p('');
  p('QUANTIDADE POR TIPO DE OBJETO NO RDS:');
  FOR r IN (SELECT o.owner, o.object_type, COUNT(*) AS qtd
              FROM dba_objects o JOIN mig_schemas m ON m.username = o.owner
             WHERE m.importar = 'S'
             GROUP BY o.owner, o.object_type
             ORDER BY 1, 2) LOOP
    p('   ' || RPAD(r.owner, 30) || RPAD(r.object_type, 25) || LPAD(r.qtd, 8));
  END LOOP;

  p('');
  p('================================================================');
  p(' PARA CONFERIR: rode este SELECT no banco de ORIGEM (on-premises)');
  p(' e compare com a tabela acima. Os numeros devem bater.');
  p('');
  p('   SELECT owner, object_type, COUNT(*)');
  p('     FROM dba_objects');
  p('    WHERE owner IN (' || v_lista || ')');
  p('    GROUP BY owner, object_type ORDER BY 1, 2;');
  p('');
  p(' Se bater: import concluido! Depois, se quiser liberar espaco:');
  p('    @07_limpeza.sql');
  p('================================================================');
END;
/

SPOOL OFF
