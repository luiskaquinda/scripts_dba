-- =====================================================================
--  98 - APAGAR os schemas importados para refazer o import do zero
--  !!! SO USE SE O IMPORT DEU ERRADO E O GUSTAVO PEDIU !!!
--  Rodar com:  @98_reset_import.sql
-- =====================================================================
@@00_config.sql
SPOOL passo98_resultado.txt

PROMPT
PROMPT ================================================================
PROMPT  98 - APAGAR SCHEMAS IMPORTADOS (para refazer o import)
PROMPT  CUIDADO: apaga os schemas abaixo com TODOS os dados no RDS.
PROMPT  O banco de ORIGEM nao e afetado.
PROMPT ================================================================
PROMPT

@@zz_controle.sql

VARIABLE pode VARCHAR2(1)

DECLARE
  v_n  NUMBER := 0;
  PROCEDURE p(t VARCHAR2) IS BEGIN DBMS_OUTPUT.PUT_LINE(t); END;
BEGIN
  :pode := 'N';

  SELECT COUNT(*) INTO v_n FROM dba_datapump_jobs
   WHERE owner_name = USER AND state = 'EXECUTING';
  IF v_n > 0 THEN
    p('[PARADO] Tem import rodando agora. Nao vou apagar nada.');
    p('         Na pergunta abaixo, so aperte ENTER.');
    RETURN;
  END IF;

  v_n := 0;
  p('Schemas que SERAO APAGADOS do RDS:');
  FOR s IN (SELECT m.username,
                   (SELECT COUNT(*) FROM dba_objects o WHERE o.owner = m.username) AS qtd
              FROM mig_schemas m JOIN dba_users u ON u.username = m.username
             WHERE m.importar = 'S'
               AND u.oracle_maintained = 'N'
               AND m.username NOT IN ('ADMIN','RDSADMIN','SYS','SYSTEM')
             ORDER BY m.username) LOOP
    v_n := v_n + 1;
    p('   - ' || RPAD(s.username, 30) || s.qtd || ' objetos');
  END LOOP;

  IF v_n = 0 THEN
    p('   (nenhum - nada para apagar)');
    p('Na pergunta abaixo, so aperte ENTER.');
    RETURN;
  END IF;

  :pode := 'S';
  p('');
END;
/

ACCEPT confirma CHAR PROMPT '>>> Para APAGAR esses schemas digite APAGAR (ou ENTER para cancelar): '

DECLARE
  h   NUMBER;
  PROCEDURE p(t VARCHAR2) IS BEGIN DBMS_OUTPUT.PUT_LINE(t); END;
BEGIN
  IF NVL(:pode, 'N') <> 'S' OR NVL(UPPER(TRIM('&confirma')), 'X') <> 'APAGAR' THEN
    p('[CANCELADO] Nada foi apagado.');
    RETURN;
  END IF;

  -- remove job de import parado, se houver
  FOR j IN (SELECT job_name FROM dba_datapump_jobs
             WHERE owner_name = USER AND job_name = '&JOB_IMP') LOOP
    BEGIN
      h := DBMS_DATAPUMP.ATTACH(j.job_name, USER);
      DBMS_DATAPUMP.STOP_JOB(h, 1, 0);
    EXCEPTION WHEN OTHERS THEN
      BEGIN EXECUTE IMMEDIATE 'DROP TABLE "' || USER || '"."' || j.job_name || '" PURGE';
      EXCEPTION WHEN OTHERS THEN NULL; END;
    END;
  END LOOP;

  FOR s IN (SELECT m.username
              FROM mig_schemas m JOIN dba_users u ON u.username = m.username
             WHERE m.importar = 'S'
               AND u.oracle_maintained = 'N'
               AND m.username NOT IN ('ADMIN','RDSADMIN','SYS','SYSTEM')) LOOP
    BEGIN
      EXECUTE IMMEDIATE 'DROP USER "' || s.username || '" CASCADE';
      p('[OK] Apagado: ' || s.username);
    EXCEPTION WHEN OTHERS THEN
      p('[ERRO] ' || s.username || ': ' || SQLERRM);
      IF SQLCODE = -1940 THEN
        p('       Tem gente conectada nesse schema. Derrube as sessoes e rode de novo.');
      END IF;
    END;
  END LOOP;

  p('');
  p('PROXIMO PASSO: @04_importar.sql');
END;
/
UNDEFINE confirma

SPOOL OFF
