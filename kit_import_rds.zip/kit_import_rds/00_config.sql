-- =====================================================================
--  00_config.sql  -  configuracao comum (NAO PRECISA RODAR NEM MEXER)
--  Os outros scripts chamam este arquivo sozinhos.
--  So altere DUMP_FILE se o nome do dump for diferente de FULLDB.dmp
-- =====================================================================
SET DEFINE ON
SET VERIFY OFF
SET FEEDBACK OFF
SET ECHO OFF
SET HEADING ON
SET LINESIZE 200
SET PAGESIZE 200
SET TRIMSPOOL ON
SET TRIMOUT ON
SET TAB OFF
SET SQLBLANKLINES ON
SET SERVEROUTPUT ON SIZE UNLIMITED FORMAT WRAPPED

DEFINE DUMP_FILE = 'FULLDB.dmp'
DEFINE DP_DIR    = 'DATA_PUMP_DIR'
DEFINE JOB_IMP   = 'IMP_MIGRACAO'
DEFINE LOG_IMP   = 'imp_migracao.log'
DEFINE JOB_CHK   = 'CHK_DUMP'
