-- =====================================================================
--  PASSO 05 - Acompanhar o import (rode quantas vezes quiser)
--  Rodar com:  @05_acompanhar.sql
-- =====================================================================
@@00_config.sql
SPOOL passo05_resultado.txt

PROMPT
PROMPT ================================================================
PROMPT  PASSO 05 - Situacao do import
PROMPT ================================================================
PROMPT

DECLARE
  TYPE t_linhas IS TABLE OF VARCHAR2(4000);
  linhas    t_linhas := t_linhas();
  h         NUMBER;
  js        VARCHAR2(30);
  sts       ku$_Status;
  v_state   VARCHAR2(30);
  v_ult     VARCHAR2(4000);
  v_tem_log BOOLEAN := TRUE;
  v_fim_ok  BOOLEAN := FALSE;

  PROCEDURE p(t VARCHAR2) IS BEGIN DBMS_OUTPUT.PUT_LINE(t); END;
BEGIN
  BEGIN
    SELECT text BULK COLLECT INTO linhas
      FROM TABLE(rdsadmin.rds_file_util.read_text_file('&DP_DIR', '&LOG_IMP'));
  EXCEPTION WHEN OTHERS THEN v_tem_log := FALSE;
  END;

  BEGIN
    SELECT state INTO v_state FROM dba_datapump_jobs
     WHERE owner_name = USER AND job_name = '&JOB_IMP';
  EXCEPTION WHEN NO_DATA_FOUND THEN v_state := NULL;
  END;

  IF v_state IN ('EXECUTING', 'DEFINING') THEN
    BEGIN
      h := DBMS_DATAPUMP.ATTACH('&JOB_IMP', USER);
      DBMS_DATAPUMP.GET_STATUS(h, DBMS_DATAPUMP.KU$_STATUS_JOB_STATUS, 0, js, sts);
      IF sts.job_status IS NOT NULL THEN
        p('[RODANDO] ' || NVL(ROUND(sts.job_status.percent_done), 0) || '% concluido' ||
          '  |  avisos/erros ate agora: ' || NVL(sts.job_status.error_count, 0));
      ELSE
        p('[RODANDO]');
      END IF;
      DBMS_DATAPUMP.DETACH(h);
    EXCEPTION
      WHEN OTHERS THEN
        p('[RODANDO] (nao consegui ler o percentual, mas esta rodando)');
        BEGIN DBMS_DATAPUMP.DETACH(h); EXCEPTION WHEN OTHERS THEN NULL; END;
    END;
    p('O percentual fica parado um tempo no comeco e no fim (indices) - e normal.');
    p('Rode de novo daqui a alguns minutos: @05_acompanhar.sql');

  ELSIF v_state IS NOT NULL THEN
    p('[ATENCAO] O import existe mas esta PARADO (estado: ' || v_state || ').');
    p('          Mande o arquivo passo05_resultado.txt para o Gustavo.');

  ELSIF NOT v_tem_log THEN
    p('[?] Nenhum import encontrado. Voce ja rodou o passo 04?');

  ELSE
    FOR i IN REVERSE 1 .. linhas.COUNT LOOP
      IF linhas(i) LIKE 'Job %' THEN v_ult := linhas(i); EXIT; END IF;
    END LOOP;

    IF v_ult LIKE '%successfully completed%' THEN
      p('[TERMINOU] Import concluido SEM erros.');
      v_fim_ok := TRUE;
    ELSIF v_ult LIKE '%completed with%' THEN
      p('[TERMINOU] Import concluido com ' || REGEXP_SUBSTR(v_ult, '[0-9]+ error') || '(s).');
      p('           E normal ter alguns. O passo 06 explica cada um.');
      v_fim_ok := TRUE;
    ELSE
      p('[ATENCAO] O import parou antes de terminar.');
      p('          Mande o arquivo passo05_resultado.txt para o Gustavo.');
    END IF;

    IF v_fim_ok THEN
      p('');
      p('PROXIMO PASSO: @06_pos_import.sql');
    END IF;
  END IF;

  IF v_tem_log AND linhas.COUNT > 0 THEN
    p('');
    p('--- ultimas linhas do log (&LOG_IMP) ---');
    FOR i IN GREATEST(1, linhas.COUNT - 9) .. linhas.COUNT LOOP
      p('  ' || SUBSTR(linhas(i), 1, 190));
    END LOOP;
  END IF;
END;
/

SPOOL OFF
