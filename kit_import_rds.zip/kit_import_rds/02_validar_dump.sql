-- =====================================================================
--  PASSO 02 - Validar o dump e descobrir schemas e tablespaces
--  NAO importa nada. So le o arquivo de dump.
--  Rodar com:  @02_validar_dump.sql
-- =====================================================================
@@00_config.sql
SPOOL passo02_resultado.txt

PROMPT
PROMPT ================================================================
PROMPT  PASSO 02 - Validar o dump (&DUMP_FILE)
PROMPT  Nao importa nada. Pode levar alguns minutos, aguarde...
PROMPT ================================================================
PROMPT

@@zz_controle.sql

DECLARE
  h         NUMBER;
  v_state   VARCHAR2(30);
  v_user    VARCHAR2(128);
  v_ts      VARCHAR2(128);
  v_tipo    VARCHAR2(20);
  v_motivo  VARCHAR2(200);
  v_n       NUMBER;
  v_lista   VARCHAR2(32767);

  PROCEDURE p(t VARCHAR2) IS BEGIN DBMS_OUTPUT.PUT_LINE(t); END;

  -- mostra o erro real do Data Pump (o ORA-39002 sozinho nao diz nada)
  PROCEDURE erros_dp(ph NUMBER) IS
    js  VARCHAR2(30);
    sts ku$_Status;
    le  ku$_LogEntry;
    i   NUMBER;
  BEGIN
    DBMS_DATAPUMP.GET_STATUS(ph, DBMS_DATAPUMP.KU$_STATUS_JOB_ERROR, 0, js, sts);
    IF BITAND(sts.mask, DBMS_DATAPUMP.KU$_STATUS_JOB_ERROR) <> 0 THEN
      le := sts.error;
      IF le IS NOT NULL THEN
        i := le.FIRST;
        WHILE i IS NOT NULL LOOP
          p('       ' || le(i).LogText);
          i := le.NEXT(i);
        END LOOP;
      END IF;
    END IF;
  EXCEPTION WHEN OTHERS THEN NULL;
  END;

  FUNCTION motivo_ignorar(u VARCHAR2) RETURN VARCHAR2 IS
    v NUMBER;
  BEGIN
    IF u IN ('ADMIN','RDSADMIN','RDSSEC','RDS_DATAGUARD','PUBLIC') THEN
      RETURN 'reservado do RDS';
    END IF;
    IF u IN ('SYS','SYSTEM','OUTLN','DBSNMP','APPQOSSYS','AUDSYS','CTXSYS','DBSFWUSER',
             'DVF','DVSYS','GGSYS','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS',
             'ORACLE_OCM','ORDDATA','ORDPLUGINS','ORDSYS','REMOTE_SCHEDULER_AGENT',
             'SI_INFORMTN_SCHEMA','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC',
             'WMSYS','XDB','XS$NULL','ANONYMOUS','DIP','EXFSYS','MGMT_VIEW','SYSMAN',
             'OWBSYS','OWBSYS_AUDIT','DMSYS','TSMSYS','PERFSTAT','SCOTT','HR','OE',
             'PM','SH','IX','BI')
       OR REGEXP_LIKE(u, '^(APEX_|FLOWS_|ORDS_|SPATIAL_|GSM)') THEN
      RETURN 'interno do Oracle';
    END IF;
    SELECT COUNT(*) INTO v FROM dba_users WHERE username = u AND oracle_maintained = 'Y';
    IF v > 0 THEN RETURN 'interno do Oracle'; END IF;
    RETURN NULL;
  END;

  PROCEDURE add_ts(n VARCHAR2, tipo VARCHAR2) IS
  BEGIN
    IF n IS NULL OR n IN ('SYSTEM','SYSAUX') OR tipo = 'UNDO' THEN RETURN; END IF;
    INSERT INTO mig_tablespaces (tablespace_name, tipo)
    SELECT n, tipo FROM dual
     WHERE NOT EXISTS (SELECT 1 FROM mig_tablespaces WHERE tablespace_name = n);
  END;

BEGIN
  -- 1) remove sobra de uma execucao anterior deste passo
  FOR j IN (SELECT job_name FROM dba_datapump_jobs
             WHERE owner_name = USER AND job_name = '&JOB_CHK') LOOP
    BEGIN
      h := DBMS_DATAPUMP.ATTACH(j.job_name, USER);
      DBMS_DATAPUMP.STOP_JOB(h, 1, 0);
    EXCEPTION WHEN OTHERS THEN
      BEGIN
        EXECUTE IMMEDIATE 'DROP TABLE "' || USER || '"."' || j.job_name || '" PURGE';
      EXCEPTION WHEN OTHERS THEN NULL;
      END;
    END;
  END LOOP;
  h := NULL;

  -- 2) o arquivo de dump esta no diretorio?
  SELECT COUNT(*) INTO v_n
    FROM TABLE(rdsadmin.rds_file_util.listdir('&DP_DIR'))
   WHERE filename = '&DUMP_FILE';

  IF v_n = 0 THEN
    p('[ERRO] O arquivo &DUMP_FILE NAO esta no &DP_DIR');
    p('       O QUE FAZER: baixar o dump do S3 para o RDS antes deste passo.');
    p('       Mande o arquivo passo02_resultado.txt para o Gustavo.');
    RETURN;
  END IF;

  -- 3) le o dump (gera so o DDL de usuarios e tablespaces)
  BEGIN
    h := DBMS_DATAPUMP.OPEN('SQL_FILE', 'FULL', NULL, '&JOB_CHK');
    DBMS_DATAPUMP.ADD_FILE(h, '&DUMP_FILE',  '&DP_DIR', NULL, DBMS_DATAPUMP.KU$_FILE_TYPE_DUMP_FILE);
    DBMS_DATAPUMP.ADD_FILE(h, 'chk_dump.sql', '&DP_DIR', NULL, DBMS_DATAPUMP.KU$_FILE_TYPE_SQL_FILE, reusefile => 1);
    DBMS_DATAPUMP.ADD_FILE(h, 'chk_dump.log', '&DP_DIR', NULL, DBMS_DATAPUMP.KU$_FILE_TYPE_LOG_FILE, reusefile => 1);
    DBMS_DATAPUMP.METADATA_FILTER(h, 'INCLUDE_PATH_EXPR', 'IN (''TABLESPACE'',''USER'',''TABLESPACE_QUOTA'')');
    DBMS_DATAPUMP.START_JOB(h);
    DBMS_DATAPUMP.WAIT_FOR_JOB(h, v_state);
  EXCEPTION
    WHEN OTHERS THEN
      p('[ERRO] Nao foi possivel ler o dump: ' || SQLERRM);
      erros_dp(h);
      BEGIN DBMS_DATAPUMP.STOP_JOB(h, 1, 0); EXCEPTION WHEN OTHERS THEN NULL; END;
      p('');
      p('       Causas comuns: dump incompleto, corrompido ou de versao mais nova que o RDS.');
      p('       Mande o arquivo passo02_resultado.txt para o Gustavo.');
      RETURN;
  END;

  IF v_state <> 'COMPLETED' THEN
    p('[ERRO] A leitura do dump terminou com estado: ' || v_state);
    FOR r IN (SELECT text FROM TABLE(rdsadmin.rds_file_util.read_text_file('&DP_DIR', 'chk_dump.log'))) LOOP
      p('       ' || r.text);
    END LOOP;
    p('       Mande o arquivo passo02_resultado.txt para o Gustavo.');
    RETURN;
  END IF;

  -- 4) analisa o que tem no dump
  DELETE FROM mig_schemas;
  DELETE FROM mig_tablespaces;

  FOR r IN (SELECT text FROM TABLE(rdsadmin.rds_file_util.read_text_file('&DP_DIR', 'chk_dump.sql'))) LOOP

    v_user := REGEXP_SUBSTR(r.text, 'CREATE USER "([^"]+)"', 1, 1, 'i', 1);
    IF v_user IS NOT NULL THEN
      v_motivo := motivo_ignorar(v_user);
      INSERT INTO mig_schemas (username, importar, motivo)
      SELECT v_user, CASE WHEN v_motivo IS NULL THEN 'S' ELSE 'N' END, v_motivo
        FROM dual
       WHERE NOT EXISTS (SELECT 1 FROM mig_schemas WHERE username = v_user);
    END IF;

    v_ts := REGEXP_SUBSTR(r.text,
              'CREATE\s+(BIGFILE\s+|SMALLFILE\s+)?(UNDO\s+|TEMPORARY\s+)?TABLESPACE\s+"([^"]+)"',
              1, 1, 'i', 3);
    IF v_ts IS NOT NULL THEN
      v_tipo := CASE
                  WHEN REGEXP_LIKE(r.text, 'UNDO\s+TABLESPACE', 'i')      THEN 'UNDO'
                  WHEN REGEXP_LIKE(r.text, 'TEMPORARY\s+TABLESPACE', 'i') THEN 'TEMPORARY'
                  ELSE 'PERMANENT'
                END;
      add_ts(v_ts, v_tipo);
    ELSE
      add_ts(REGEXP_SUBSTR(r.text, 'DEFAULT\s+TABLESPACE\s+"([^"]+)"',   1, 1, 'i', 1), 'PERMANENT');
      add_ts(REGEXP_SUBSTR(r.text, 'TEMPORARY\s+TABLESPACE\s+"([^"]+)"', 1, 1, 'i', 1), 'TEMPORARY');
      add_ts(REGEXP_SUBSTR(r.text, 'QUOTA\s+\S+\s+ON\s+"([^"]+)"',       1, 1, 'i', 1), 'PERMANENT');
    END IF;
  END LOOP;

  UPDATE mig_tablespaces t
     SET existe = CASE WHEN EXISTS (SELECT 1 FROM dba_tablespaces d
                                     WHERE d.tablespace_name = t.tablespace_name)
                       THEN 'S' ELSE 'N' END;
  COMMIT;

  -- 5) relatorio
  p('================================================================');
  p(' [OK] O dump foi lido com sucesso.');
  p('================================================================');
  p('');

  SELECT COUNT(*) INTO v_n FROM mig_schemas WHERE importar = 'S';
  IF v_n = 0 THEN
    p('[ERRO] Nao encontrei nenhum schema de aplicacao dentro do dump.');
    p('       O export pode ter sido feito so de tabelas, ou sem privilegio de DBA.');
    p('       Mande o arquivo passo02_resultado.txt para o Gustavo.');
    RETURN;
  END IF;

  p('SCHEMAS DA APLICACAO (serao importados): ' || v_n);
  FOR s IN (SELECT username FROM mig_schemas WHERE importar = 'S' ORDER BY username) LOOP
    p('   - ' || s.username);
  END LOOP;
  p('');

  v_lista := NULL;
  FOR s IN (SELECT username FROM mig_schemas WHERE importar = 'N' ORDER BY username) LOOP
    v_lista := v_lista || CASE WHEN v_lista IS NOT NULL THEN ', ' END || s.username;
  END LOOP;
  IF v_lista IS NOT NULL THEN
    p('Schemas ignorados (internos do Oracle/RDS, ja existem no RDS):');
    p('   ' || v_lista);
    p('');
  END IF;

  p('TABLESPACES:');
  FOR t IN (SELECT tablespace_name, tipo, existe FROM mig_tablespaces ORDER BY tablespace_name) LOOP
    p('   - ' || RPAD(t.tablespace_name, 30) || RPAD(t.tipo, 11) ||
      CASE WHEN t.existe = 'S' THEN 'ja existe no RDS' ELSE 'FALTA (o passo 03 cria)' END);
  END LOOP;
  p('');

  -- avisos que apareceram na leitura
  v_n := 0;
  FOR r IN (SELECT text FROM TABLE(rdsadmin.rds_file_util.read_text_file('&DP_DIR', 'chk_dump.log'))
             WHERE text LIKE '%ORA-%') LOOP
    IF v_n = 0 THEN p('Avisos na leitura do dump:'); END IF;
    v_n := v_n + 1;
    p('   ' || r.text);
  END LOOP;

  p('================================================================');
  p(' PROXIMO PASSO: @03_preparar_tablespaces.sql');
  p('================================================================');
END;
/

SPOOL OFF
