-- =====================================================================
--  PASSO 04 - Importar (confere tudo antes e pede confirmacao)
--  Rodar com:  @04_importar.sql
-- =====================================================================
@@00_config.sql
SPOOL passo04_resultado.txt

PROMPT
PROMPT ================================================================
PROMPT  PASSO 04 - Importar os schemas da aplicacao
PROMPT ================================================================
PROMPT

@@zz_controle.sql

VARIABLE pode VARCHAR2(1)

-- ---------------------------------------------------------------
-- Conferencias antes de comecar
-- ---------------------------------------------------------------
DECLARE
  v_n  NUMBER;
  v_ok BOOLEAN := TRUE;

  PROCEDURE p(t VARCHAR2) IS BEGIN DBMS_OUTPUT.PUT_LINE(t); END;
BEGIN
  :pode := 'N';

  SELECT COUNT(*) INTO v_n FROM mig_schemas WHERE importar = 'S';
  IF v_n = 0 THEN
    p('[ERRO] Nenhum schema para importar. Rode primeiro: @02_validar_dump.sql');
    v_ok := FALSE;
  END IF;

  SELECT COUNT(*) INTO v_n
    FROM TABLE(rdsadmin.rds_file_util.listdir('&DP_DIR'))
   WHERE filename = '&DUMP_FILE';
  IF v_n = 0 THEN
    p('[ERRO] O arquivo &DUMP_FILE nao esta no &DP_DIR');
    v_ok := FALSE;
  END IF;

  SELECT COUNT(*) INTO v_n FROM dba_datapump_jobs
   WHERE owner_name = USER AND job_name = '&JOB_IMP';
  IF v_n > 0 THEN
    p('[ERRO] Ja existe um import (&JOB_IMP) no banco.');
    p('       Se ele esta rodando, acompanhe com: @05_acompanhar.sql');
    p('       Se ele travou, rode:                 @01_limpar_job.sql');
    v_ok := FALSE;
  END IF;

  FOR t IN (SELECT tablespace_name FROM mig_tablespaces m
             WHERE NOT EXISTS (SELECT 1 FROM dba_tablespaces d
                                WHERE d.tablespace_name = m.tablespace_name)) LOOP
    p('[ERRO] A tablespace ' || t.tablespace_name || ' nao existe. Rode: @03_preparar_tablespaces.sql');
    v_ok := FALSE;
  END LOOP;

  FOR s IN (SELECT m.username,
                   (SELECT COUNT(*) FROM dba_objects o WHERE o.owner = m.username) AS qtd
              FROM mig_schemas m
             WHERE m.importar = 'S'
               AND EXISTS (SELECT 1 FROM dba_users u WHERE u.username = m.username)) LOOP
    IF s.qtd > 0 THEN
      p('[ERRO] O schema ' || s.username || ' ja existe no RDS com ' || s.qtd || ' objetos.');
      p('       Parece que ja houve um import antes. Para apagar e refazer: @98_reset_import.sql');
      v_ok := FALSE;
    END IF;
  END LOOP;

  IF NOT v_ok THEN
    p('');
    p('================================================================');
    p(' [PARADO] Corrija os itens acima e rode este passo de novo.');
    p(' Na pergunta abaixo, so aperte ENTER.');
    p('================================================================');
    RETURN;
  END IF;

  :pode := 'S';
  p('[OK] Todas as conferencias passaram.');
  p('');
  p('Vai importar do arquivo &DUMP_FILE os schemas:');
  FOR s IN (SELECT username FROM mig_schemas WHERE importar = 'S' ORDER BY username) LOOP
    p('   - ' || s.username);
  END LOOP;
  p('');
  p('O import roda no servidor. Depois de iniciar, voce pode fechar o SQL*Plus');
  p('sem problema e acompanhar com @05_acompanhar.sql');
  p('');
END;
/

ACCEPT confirma CHAR PROMPT '>>> Digite SIM para iniciar o import (ou ENTER para cancelar): '

-- ---------------------------------------------------------------
-- Inicia o import
-- ---------------------------------------------------------------
DECLARE
  h       NUMBER;
  v_lista VARCHAR2(32767);

  PROCEDURE p(t VARCHAR2) IS BEGIN DBMS_OUTPUT.PUT_LINE(t); END;

  PROCEDURE erros_dp(ph NUMBER) IS
    js  VARCHAR2(30);
    sts ku$_Status;
    le  ku$_LogEntry;
    i   NUMBER;
  BEGIN
    DBMS_DATAPUMP.GET_STATUS(ph, DBMS_DATAPUMP.KU$_STATUS_JOB_ERROR, 0, js, sts);
    IF BITAND(sts.mask, DBMS_DATAPUMP.KU$_STATUS_JOB_ERROR) <> 0 THEN
      le := sts.error;
      IF le IS NOT NULL THEN
        i := le.FIRST;
        WHILE i IS NOT NULL LOOP
          p('       ' || le(i).LogText);
          i := le.NEXT(i);
        END LOOP;
      END IF;
    END IF;
  EXCEPTION WHEN OTHERS THEN NULL;
  END;
BEGIN
  IF NVL(:pode, 'N') <> 'S' THEN
    p('[CANCELADO] O import NAO foi iniciado (veja os erros acima).');
    RETURN;
  END IF;

  IF NVL(UPPER(TRIM('&confirma')), 'X') <> 'SIM' THEN
    p('[CANCELADO] O import NAO foi iniciado. Nada foi alterado.');
    RETURN;
  END IF;

  FOR s IN (SELECT username FROM mig_schemas WHERE importar = 'S' ORDER BY username) LOOP
    v_lista := v_lista || CASE WHEN v_lista IS NOT NULL THEN ',' END || '''' || s.username || '''';
  END LOOP;

  BEGIN
    h := DBMS_DATAPUMP.OPEN('IMPORT', 'SCHEMA', NULL, '&JOB_IMP');
    DBMS_DATAPUMP.ADD_FILE(h, '&DUMP_FILE', '&DP_DIR', NULL, DBMS_DATAPUMP.KU$_FILE_TYPE_DUMP_FILE);
    DBMS_DATAPUMP.ADD_FILE(h, '&LOG_IMP',   '&DP_DIR', NULL, DBMS_DATAPUMP.KU$_FILE_TYPE_LOG_FILE, reusefile => 1);
    DBMS_DATAPUMP.METADATA_FILTER(h, 'SCHEMA_EXPR', 'IN (' || v_lista || ')');
    DBMS_DATAPUMP.METADATA_FILTER(h, 'EXCLUDE_PATH_EXPR', 'IN (''STATISTICS'')');
    DBMS_DATAPUMP.SET_PARAMETER(h, 'TABLE_EXISTS_ACTION', 'SKIP');
    -- SEM SET_PARALLEL: o RDS e Standard Edition 2, que nao suporta paralelismo
    DBMS_DATAPUMP.START_JOB(h);
    DBMS_DATAPUMP.DETACH(h);
  EXCEPTION
    WHEN OTHERS THEN
      p('[ERRO] O import nao conseguiu iniciar: ' || SQLERRM);
      erros_dp(h);
      BEGIN DBMS_DATAPUMP.STOP_JOB(h, 1, 0); EXCEPTION WHEN OTHERS THEN NULL; END;
      p('       O job foi limpo, nao ficou nada travado.');
      p('       Mande o arquivo passo04_resultado.txt para o Gustavo.');
      RETURN;
  END;

  p('');
  p('================================================================');
  p(' [OK] IMPORT INICIADO.');
  p(' Ele roda sozinho no servidor (sem paralelismo, pode levar 30-90 min).');
  p(' PROXIMO PASSO: @05_acompanhar.sql  (rode de tempos em tempos)');
  p('================================================================');
END;
/

UNDEFINE confirma
SPOOL OFF
