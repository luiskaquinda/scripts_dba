-- =====================================================================
--  PASSO 03 - Criar no RDS as tablespaces que o dump precisa
--  Rodar com:  @03_preparar_tablespaces.sql
-- =====================================================================
@@00_config.sql
SPOOL passo03_resultado.txt

PROMPT
PROMPT ================================================================
PROMPT  PASSO 03 - Criar as tablespaces que faltam
PROMPT ================================================================
PROMPT

@@zz_controle.sql

DECLARE
  v_n       NUMBER;
  v_criadas NUMBER := 0;
  v_erros   NUMBER := 0;

  PROCEDURE p(t VARCHAR2) IS BEGIN DBMS_OUTPUT.PUT_LINE(t); END;
BEGIN
  SELECT COUNT(*) INTO v_n FROM mig_schemas;
  IF v_n = 0 THEN
    p('[ERRO] O passo 02 ainda nao foi rodado (ou falhou).');
    p('       Rode primeiro: @02_validar_dump.sql');
    RETURN;
  END IF;

  FOR t IN (SELECT tablespace_name, tipo FROM mig_tablespaces ORDER BY tablespace_name) LOOP
    SELECT COUNT(*) INTO v_n FROM dba_tablespaces WHERE tablespace_name = t.tablespace_name;

    IF v_n > 0 THEN
      p('[OK]     ' || RPAD(t.tablespace_name, 30) || 'ja existe');
    ELSE
      BEGIN
        IF t.tipo = 'TEMPORARY' THEN
          EXECUTE IMMEDIATE 'CREATE TEMPORARY TABLESPACE "' || t.tablespace_name ||
                            '" TEMPFILE SIZE 100M AUTOEXTEND ON NEXT 100M MAXSIZE UNLIMITED';
        ELSE
          EXECUTE IMMEDIATE 'CREATE TABLESPACE "' || t.tablespace_name ||
                            '" DATAFILE SIZE 100M AUTOEXTEND ON NEXT 256M MAXSIZE UNLIMITED';
        END IF;
        v_criadas := v_criadas + 1;
        p('[CRIADA] ' || RPAD(t.tablespace_name, 30) || t.tipo);
      EXCEPTION
        WHEN OTHERS THEN
          v_erros := v_erros + 1;
          p('[ERRO]   ' || RPAD(t.tablespace_name, 30) || SQLERRM);
      END;
    END IF;
  END LOOP;

  UPDATE mig_tablespaces t
     SET existe = CASE WHEN EXISTS (SELECT 1 FROM dba_tablespaces d
                                     WHERE d.tablespace_name = t.tablespace_name)
                       THEN 'S' ELSE 'N' END;
  COMMIT;

  p('');
  p('================================================================');
  IF v_erros > 0 THEN
    p(' RESULTADO: ' || v_erros || ' tablespace(s) nao foram criadas.');
    p(' Mande o arquivo passo03_resultado.txt para o Gustavo.');
  ELSE
    p(' RESULTADO: [OK] ' || v_criadas || ' tablespace(s) criada(s). Tudo pronto.');
    p(' PROXIMO PASSO: @04_importar.sql');
  END IF;
  p('================================================================');
END;
/

SPOOL OFF
