-- =====================================================================
--  PASSO 01 - Limpar jobs de Data Pump travados
--  Rodar com:  @01_limpar_job.sql
-- =====================================================================
@@00_config.sql
SPOOL passo01_resultado.txt

PROMPT
PROMPT ================================================================
PROMPT  PASSO 01 - Limpar jobs de Data Pump travados
PROMPT ================================================================
PROMPT

@@zz_controle.sql

DECLARE
  h        NUMBER;
  v_limpos NUMBER := 0;
  v_erros  NUMBER := 0;
  v_rodando NUMBER := 0;

  PROCEDURE p(t VARCHAR2) IS BEGIN DBMS_OUTPUT.PUT_LINE(t); END;
BEGIN
  FOR j IN (SELECT owner_name, job_name, state
              FROM dba_datapump_jobs
             WHERE owner_name = USER
             ORDER BY job_name) LOOP

    IF j.state = 'EXECUTING' THEN
      v_rodando := v_rodando + 1;
      p('[ATENCAO] O job ' || j.job_name || ' esta RODANDO agora. Nao mexi nele.');
      p('          Se for o import, acompanhe com: @05_acompanhar.sql');
    ELSE
      BEGIN
        h := DBMS_DATAPUMP.ATTACH(j.job_name, j.owner_name);
        DBMS_DATAPUMP.STOP_JOB(h, 1, 0);
        v_limpos := v_limpos + 1;
        p('[OK] Job travado removido: ' || j.job_name || ' (estava ' || j.state || ')');
      EXCEPTION
        WHEN OTHERS THEN
          BEGIN
            EXECUTE IMMEDIATE 'DROP TABLE "' || j.owner_name || '"."' || j.job_name || '" PURGE';
            v_limpos := v_limpos + 1;
            p('[OK] Job travado removido: ' || j.job_name || ' (estava ' || j.state || ')');
          EXCEPTION
            WHEN OTHERS THEN
              v_erros := v_erros + 1;
              p('[ERRO] Nao consegui remover o job ' || j.job_name || ': ' || SQLERRM);
          END;
      END;
    END IF;
  END LOOP;

  p('');
  p('================================================================');
  IF v_erros > 0 THEN
    p(' RESULTADO: ainda tem job travado.');
    p(' O QUE FAZER: digite EXIT, conecte de novo no SQL*Plus');
    p('              e rode este passo outra vez (@01_limpar_job.sql).');
  ELSIF v_rodando > 0 THEN
    p(' RESULTADO: tem um job rodando. Nao siga para o passo 02 agora.');
  ELSIF v_limpos = 0 THEN
    p(' RESULTADO: [OK] Nenhum job travado.');
    p(' PROXIMO PASSO: @02_validar_dump.sql');
  ELSE
    p(' RESULTADO: [OK] ' || v_limpos || ' job(s) travado(s) removido(s).');
    p(' PROXIMO PASSO: @02_validar_dump.sql');
  END IF;
  p('================================================================');
END;
/

SPOOL OFF
