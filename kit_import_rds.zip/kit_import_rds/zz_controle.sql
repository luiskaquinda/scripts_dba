-- =====================================================================
--  zz_controle.sql  -  cria as tabelas de controle do kit (NAO PRECISA RODAR)
--  Chamado automaticamente pelos passos 01 e 02.
-- =====================================================================
DECLARE
  PROCEDURE criar(p_sql VARCHAR2) IS
  BEGIN
    EXECUTE IMMEDIATE p_sql;
  EXCEPTION
    WHEN OTHERS THEN
      IF SQLCODE <> -955 THEN RAISE; END IF;   -- -955 = ja existe
  END;
BEGIN
  criar('CREATE TABLE mig_schemas (username VARCHAR2(128) PRIMARY KEY, importar CHAR(1), motivo VARCHAR2(200))');
  criar('CREATE TABLE mig_tablespaces (tablespace_name VARCHAR2(128) PRIMARY KEY, tipo VARCHAR2(20), existe CHAR(1))');
END;
/
