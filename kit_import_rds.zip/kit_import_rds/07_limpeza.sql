-- =====================================================================
--  PASSO 07 - Limpar arquivos que sobraram no DATA_PUMP_DIR
--  SO RODE DEPOIS QUE O IMPORT ESTIVER CONFERIDO (passo 06)
--  Rodar com:  @07_limpeza.sql
-- =====================================================================
@@00_config.sql
SPOOL passo07_resultado.txt

PROMPT
PROMPT ================================================================
PROMPT  PASSO 07 - Limpeza do DATA_PUMP_DIR
PROMPT ================================================================
PROMPT

VARIABLE pode VARCHAR2(1)

DECLARE
  v_n  NUMBER := 0;
  v_mb NUMBER := 0;

  PROCEDURE p(t VARCHAR2) IS BEGIN DBMS_OUTPUT.PUT_LINE(t); END;
BEGIN
  :pode := 'N';

  SELECT COUNT(*) INTO v_n FROM dba_datapump_jobs WHERE owner_name = USER;
  IF v_n > 0 THEN
    p('[PARADO] Tem job de Data Pump no banco. Nao vou apagar nada agora.');
    p('         Na pergunta abaixo, so aperte ENTER.');
    RETURN;
  END IF;

  p('Arquivos que SERAO APAGADOS (copias duplicadas, dumps antigos e logs velhos):');
  p('');
  v_n := 0;
  FOR f IN (SELECT filename, filesize
              FROM TABLE(rdsadmin.rds_file_util.listdir('&DP_DIR'))
             WHERE "TYPE" = 'file'
               AND filename <> '&DUMP_FILE'
               AND filename <> '&LOG_IMP'
               AND (   filename LIKE '&DUMP_FILE%'
                    OR filename LIKE 'EXPDAT%.DMP'
                    OR filename LIKE '%.log'
                    OR filename = 'chk_dump.sql')
             ORDER BY filename) LOOP
    v_n  := v_n + 1;
    v_mb := v_mb + f.filesize / 1024 / 1024;
    p('   ' || RPAD(f.filename, 45) || LPAD(ROUND(f.filesize / 1024 / 1024) || ' MB', 12));
  END LOOP;

  IF v_n = 0 THEN
    p('   (nada para apagar)');
  ELSE
    :pode := 'S';
    p('');
    p('Total: ' || v_n || ' arquivo(s), ' || ROUND(v_mb) || ' MB');
    p('Ficam guardados: &DUMP_FILE (o dump) e &LOG_IMP (log do import).');
  END IF;
  p('');
END;
/

ACCEPT confirma CHAR PROMPT '>>> Digite SIM para apagar os arquivos listados (ou ENTER para cancelar): '

DECLARE
  v_n NUMBER := 0;
  PROCEDURE p(t VARCHAR2) IS BEGIN DBMS_OUTPUT.PUT_LINE(t); END;
BEGIN
  IF NVL(:pode, 'N') <> 'S' OR NVL(UPPER(TRIM('&confirma')), 'X') <> 'SIM' THEN
    p('[CANCELADO] Nenhum arquivo foi apagado.');
    RETURN;
  END IF;

  FOR f IN (SELECT filename
              FROM TABLE(rdsadmin.rds_file_util.listdir('&DP_DIR'))
             WHERE "TYPE" = 'file'
               AND filename <> '&DUMP_FILE'
               AND filename <> '&LOG_IMP'
               AND (   filename LIKE '&DUMP_FILE%'
                    OR filename LIKE 'EXPDAT%.DMP'
                    OR filename LIKE '%.log'
                    OR filename = 'chk_dump.sql')) LOOP
    BEGIN
      UTL_FILE.FREMOVE('&DP_DIR', f.filename);
      v_n := v_n + 1;
    EXCEPTION WHEN OTHERS THEN
      p('[AVISO] Nao consegui apagar ' || f.filename || ': ' || SQLERRM);
    END;
  END LOOP;
  p('[OK] ' || v_n || ' arquivo(s) apagado(s).');
END;
/
UNDEFINE confirma

PROMPT
PROMPT O dump principal (&DUMP_FILE) ainda esta no RDS ocupando espaco.
PROMPT So apague se o import ja foi conferido e a aplicacao esta funcionando.
PROMPT (uma copia continua no bucket S3, se voce subiu para la)
PROMPT
ACCEPT confirma2 CHAR PROMPT '>>> Digite SIM para apagar tambem o &DUMP_FILE (ou ENTER para manter): '

DECLARE
  PROCEDURE p(t VARCHAR2) IS BEGIN DBMS_OUTPUT.PUT_LINE(t); END;
BEGIN
  IF NVL(UPPER(TRIM('&confirma2')), 'X') <> 'SIM' THEN
    p('[OK] &DUMP_FILE mantido.');
    RETURN;
  END IF;
  UTL_FILE.FREMOVE('&DP_DIR', '&DUMP_FILE');
  p('[OK] &DUMP_FILE apagado.');
EXCEPTION WHEN OTHERS THEN
  p('[AVISO] Nao consegui apagar o dump: ' || SQLERRM);
END;
/
UNDEFINE confirma2

PROMPT
PROMPT ================================================================
PROMPT  Limpeza concluida. Migracao finalizada!
PROMPT ================================================================

SPOOL OFF
