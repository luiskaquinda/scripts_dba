
select '-- ** Gera Scripts para criar synonym do ususario OWMALL para o ususario USMALL ** --' command from dual
union all
select  'create or replace synonym  usmALL.'||object_name||' for '||owner||'.'||object_name||';' command
from dba_objects where owner ='OWMALL' and  object_type in('TABLE', 'PACKAGE','PROCEDURE','VIEW','SEQUENCE') 
union all
select '-- ** Gera Scripts para criar grant do ususario OWMALL para o ususario USMALL ** --' command from dual
union all
select  'grant '||decode(object_type,'TABLE','select,insert,update,delete', 'FUNCTION','execute', 'PACKAGE','execute','PROCEDURE','execute','VIEW','SELECT','SEQUENCE','SELECT')
         ||' on '|| owner||'.'||object_name||' to usmALL;'  command
from dba_objects where owner ='OWMALL' and  object_type in('TABLE', 'PACKAGE','PROCEDURE','VIEW','SEQUENCE') 
/
