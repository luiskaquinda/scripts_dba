ftp -in 200.185.21.13 <<END
user userrrrr `cat sec`
binary
cd $1
mput $2
bye
END




ftp -in 200.999.21.13 <<END
user "userrrr" ""
binary
cd GUINA_BKP1
mput orapwPRDATO
bye
END