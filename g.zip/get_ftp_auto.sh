#!/bin/sh
ftp -vn 200.185.21.10 <<SCRIPT
user userrrrrr pssss
cd 2018_07_CPU_p28317141_112040_AIX64-5L
binary
prompt off
mget *.zip
SCRIPT
exit 0
